JC's Birthday — Flower Bouquet Builder Sample V1

Standalone sample only. It does not replace the main JC's Birthday app.

Features:
- Bouquet-first interaction instead of a generic blank canvas
- Round / Wild / Cascade bouquet shapes
- 9 flower/filler types
- Tap to add flowers
- Drag flower heads to rearrange them
- Auto-arrange
- 5 color moods
- 6 wrapping paper styles
- 3 ribbon styles
- Ribbon colors
- Message card with title + note
- Studio / Blush / Blue / Night scenes
- Responsive desktop / tablet / mobile
- Mobile bottom-sheet controls
- Preview / send concept

If approved, this can later become the Flower Bouquet mode in the main JC's Birthday app and save its final bouquet data to Supabase.


V2 CARD FIX
-----------
- Message text now wraps automatically into multiple SVG lines.
- Long messages shrink slightly instead of overflowing.
- Maximum visible message lines are capped cleanly with an ellipsis.
- Card is larger with improved spacing and divider.
- Title is safely truncated if too long.
