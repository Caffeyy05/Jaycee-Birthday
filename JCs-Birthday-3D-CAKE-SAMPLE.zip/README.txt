JC's Birthday — 3D Cake Sample

This is a standalone concept sample only. It does NOT replace your current JC's Birthday site.

Features:
- Real WebGL/Three.js 3D cake
- Mouse/finger drag to rotate
- Mouse wheel / pinch zoom
- Round / square / heart cake
- 1 / 2 / 3 tiers
- Frosting color
- Sprinkles / berries / hearts / pearls
- 1–9 candles with glowing flames
- Custom topper message
- Background scene color
- Preview/send concept modal
- Responsive mobile layout

Internet is required because Three.js and Google Fonts are loaded from CDN.

If you approve this direction, the next step is to integrate the 3D Cake mode into the main JC's Birthday app and save the design to Supabase.
