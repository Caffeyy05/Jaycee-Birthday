JC's Birthday — Gift Box Builder Sample V1

Standalone sample only. It does not replace the main JC's Birthday app.

Features:
- Closed gift box → animated opening reveal
- Classic / Tall / Wide box shapes
- 6 box color themes
- 6 wrapping patterns
- 5 ribbon colors
- 12 virtual surprise types
- Up to 6 surprise items
- Optional photo surprise
- Personal gift tag title + message
- Confetti reveal animation
- Studio / Blush / Blue / Night scenes
- Responsive desktop/tablet/mobile
- Mobile bottom-sheet editor
- Preview / send concept

If approved, this can later become the Gift Box mode in the main JC's Birthday app and save the box design/photo/surprises to Supabase.
